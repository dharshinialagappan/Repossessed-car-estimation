# -*- coding: utf-8 -*-
"""
Created on Wed Jul 28 12:40:14 2021

@author: valagappan
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Apr 17 22:38:55 2021

@author: HP
"""

import pandas as pd
import numpy as np
import pickle

#importing a dataset
data = pd.read_csv('car data.csv')
data_visual= pd.read_csv('car data.csv')
print(data)


final_dataset=data[['Year','Selling_Price','Present_Price','Kms_Driven','Fuel_Type','Seller_Type','Transmission','Owner']]
final_dataset.head()
final_dataset['Current Year']=2020
final_dataset.head()
final_dataset['no_year']=final_dataset['Current Year']- final_dataset['Year']
final_dataset.head()
final_dataset.drop(['Year'],axis=1,inplace=True)
final_dataset.head()
final_dataset=pd.get_dummies(final_dataset,drop_first=True)
final_dataset.head()
final_dataset=final_dataset.drop(['Current Year'],axis=1)
final_dataset.head()



from sklearn.model_selection import train_test_split

X = final_dataset.iloc[:,:-1]
Y = final_dataset.iloc[:,0]
X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.30,random_state=40)


from sklearn.tree import DecisionTreeRegressor
regressor=DecisionTreeRegressor()
regressor.fit(X_train,Y_train)
Y_pred=regressor.predict(X_test)

from sklearn.metrics import mean_squared_error
mse = mean_squared_error(Y_test,Y_pred)
print(mse)
rmse = np.sqrt(mse)
print(rmse)


# Saving model to disk
pickle.dump(regressor, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))